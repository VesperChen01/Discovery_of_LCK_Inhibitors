
import pandas as pd
import matplotlib.pyplot as plt
import sys

# Function to read the CSV and determine the data columns
def read_and_plot_csv(filename, xlabel, ylabel):
    # Read the CSV into a DataFrame
    df = pd.read_csv(filename)

    # Prepare the plot
    plt.figure(figsize=(12, 6), dpi=300)

    # Plot each pair of data columns
    for i in range(1, len(df.columns), 2):
        plt.plot(df.iloc[:, i - 1], df.iloc[:, i], label=df.columns[i])
    
    # Labeling the axes
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title('RMSD Analysis')
    plt.legend(loc='upper left', bbox_to_anchor=(0, 1))

    # Save and show the plot
    plt.tight_layout()
    plt.savefig(filename.replace('.csv', '.png'))
    plt.show()

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Incorrect usage, correct format:")
        print("python script.py <path_to_csv> <xlabel> <ylabel>")
        sys.exit(1)
    read_and_plot_csv(sys.argv[1], sys.argv[2], sys.argv[3])
