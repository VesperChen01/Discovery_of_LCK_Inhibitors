# -*- coding: utf-8 -*-
"""
Updated script for plotting RMSD data with improved aesthetics
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys

# Check command line arguments
if len(sys.argv) < 4:
    print("Usage: python script.py <filename.csv> <x-axis label> <y-axis label>")
    sys.exit(1)

# Read command line arguments
filename = sys.argv[1]
unitsx = sys.argv[2]
unitsy = sys.argv[3]

# Read the entire CSV file into a DataFrame
data = pd.read_csv(filename)

# Prepare figure and axis
fig, ax = plt.subplots(figsize=(10, 6))

# Plot settings
colors = plt.cm.viridis(np.linspace(0, 1, data.shape[1]))
lines = ['-', '--', '-.', ':']

# Iterate over columns in DataFrame and plot
for i, column in enumerate(data.columns[1:], 1):
    ax.plot(data[data.columns[0]], data[column], linestyle=lines[i % len(lines)], label=column, color=colors[i], linewidth=1)


# Set the labels and title
ax.set_xlabel(unitsx)
ax.set_ylabel(unitsy)
ax.set_title('RMSD Analysis')

# Add legend outside of the plot
ax.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize='small')

# Set limits if necessary
# ax.set_xlim([0, data[data.columns[0]].max()])
# ax.set_ylim([0, data.max().max()])

# Tight layout often produces nicer layouts
plt.tight_layout()

# Save the plot as a PNG file
output_filename = filename.replace('.csv', '.png')
plt.savefig(output_filename, bbox_inches='tight')

# Show the plot
plt.show()
